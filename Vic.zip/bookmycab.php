<?php
    $to = 'info@victaxismelbourne.com.au';
    $name = $_POST["name"];
    $email= $_POST["email"];
    $phone= $_POST["phone"];
    $fromDestination= $_POST["fromDestination"];
	$toDestination= $_POST["toDestination"];
	$datepicker= $_POST["datepicker"];
	$timepicker= $_POST["timepicker"];

    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= "From: " . $email . "\r\n"; // Sender's E-mail
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    $message ='<table style="width:100%">
        <tr><td>Book My CAB</td></tr>
		<tr><td>Name:  '.$name.'</td></tr>
        <tr><td>Email: '.$email.'</td></tr>
        <tr><td>phone: '.$phone.'</td></tr>
        <tr><td>From Destination: '.$fromDestination.'</td></tr>
		<tr><td>To Destination: '.$toDestination.'</td></tr>
		<tr><td>Date: '.$datepicker.'</td></tr>
		<tr><td>Date: '.$timepicker.'</td></tr>
        
    </table>';

    if (@mail($to, $email, $message, $headers))
    {
        echo 'Your message has been sent.';
    }else{
        echo 'failed';
    }

?>
